"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _common = require("../../common");

var _configSchema = require("@kbn/config-schema");

function defineRoutes(router) {
  // for search documents :
  router.post({
    path: `/api/${_common.PLUGIN_ID}/elastic/search`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    let result = {};

    try {
      const payload = request.body;
      result = await context.core.elasticsearch.client.asCurrentUser.search({
        index: payload.index,
        q: payload.query,
        _source: payload._source,
        _source_excludes: payload._source_excludes,
        from: payload.from,
        size: payload.size,
        body: payload.body,
        sort: payload.sort
      });
    } catch (err) {
      var _err$meta, _err$meta$body, _err$meta$body$error, _err$meta2, _err$meta2$body, _err$meta2$body$error;

      return response.customError({
        statusCode: ((_err$meta = err.meta) === null || _err$meta === void 0 ? void 0 : (_err$meta$body = _err$meta.body) === null || _err$meta$body === void 0 ? void 0 : (_err$meta$body$error = _err$meta$body.error) === null || _err$meta$body$error === void 0 ? void 0 : _err$meta$body$error.status) || 417,
        body: {
          //message: JSON.stringify(err.meta?.body?.error) || "reason not specified"
          message: ((_err$meta2 = err.meta) === null || _err$meta2 === void 0 ? void 0 : (_err$meta2$body = _err$meta2.body) === null || _err$meta2$body === void 0 ? void 0 : (_err$meta2$body$error = _err$meta2$body.error) === null || _err$meta2$body$error === void 0 ? void 0 : _err$meta2$body$error.reason) || "reason not specified"
        }
      });
    }

    return response.ok({
      body: result
    });
  }); // for saving data:

  router.post({
    path: `/api/${_common.PLUGIN_ID}/elastic/index`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    let result = {};

    try {
      const payload = request.body;
      result = await context.core.elasticsearch.client.asCurrentUser.index({
        id: payload.id,
        index: payload.index,
        body: payload.body
      });
    } catch (err) {
      var _err$meta3, _err$meta3$body, _err$meta3$body$error, _err$meta4, _err$meta4$body, _err$meta4$body$error;

      return response.customError({
        statusCode: ((_err$meta3 = err.meta) === null || _err$meta3 === void 0 ? void 0 : (_err$meta3$body = _err$meta3.body) === null || _err$meta3$body === void 0 ? void 0 : (_err$meta3$body$error = _err$meta3$body.error) === null || _err$meta3$body$error === void 0 ? void 0 : _err$meta3$body$error.status) || 417,
        body: {
          message: ((_err$meta4 = err.meta) === null || _err$meta4 === void 0 ? void 0 : (_err$meta4$body = _err$meta4.body) === null || _err$meta4$body === void 0 ? void 0 : (_err$meta4$body$error = _err$meta4$body.error) === null || _err$meta4$body$error === void 0 ? void 0 : _err$meta4$body$error.reason) || "reason not specified"
        }
      });
    }

    return response.ok({
      body: result
    });
  }); // for delete data by query :

  router.post({
    path: `/api/${_common.PLUGIN_ID}/elastic/delete_by_query`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    let result = {};
    const payload = request.body;

    try {
      result = await context.core.elasticsearch.client.asCurrentUser.deleteByQuery({
        index: payload.index,
        q: payload.query,
        body: payload.body
      });
    } catch (err) {
      var _err$meta5, _err$meta5$body, _err$meta5$body$error, _err$meta6, _err$meta6$body, _err$meta6$body$error;

      return response.customError({
        statusCode: ((_err$meta5 = err.meta) === null || _err$meta5 === void 0 ? void 0 : (_err$meta5$body = _err$meta5.body) === null || _err$meta5$body === void 0 ? void 0 : (_err$meta5$body$error = _err$meta5$body.error) === null || _err$meta5$body$error === void 0 ? void 0 : _err$meta5$body$error.status) || 417,
        body: {
          message: ((_err$meta6 = err.meta) === null || _err$meta6 === void 0 ? void 0 : (_err$meta6$body = _err$meta6.body) === null || _err$meta6$body === void 0 ? void 0 : (_err$meta6$body$error = _err$meta6$body.error) === null || _err$meta6$body$error === void 0 ? void 0 : _err$meta6$body$error.reason) || "reason not specified"
        }
      });
    }

    return response.ok({
      body: result
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsInBvc3QiLCJwYXRoIiwiUExVR0lOX0lEIiwidmFsaWRhdGUiLCJib2R5Iiwic2NoZW1hIiwiYW55IiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsInJlc3VsdCIsInBheWxvYWQiLCJjb3JlIiwiZWxhc3RpY3NlYXJjaCIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJzZWFyY2giLCJpbmRleCIsInEiLCJxdWVyeSIsIl9zb3VyY2UiLCJfc291cmNlX2V4Y2x1ZGVzIiwiZnJvbSIsInNpemUiLCJzb3J0IiwiZXJyIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwibWV0YSIsImVycm9yIiwic3RhdHVzIiwibWVzc2FnZSIsInJlYXNvbiIsIm9rIiwiaWQiLCJkZWxldGVCeVF1ZXJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQ0E7O0FBQ0E7O0FBRU8sU0FBU0EsWUFBVCxDQUFzQkMsTUFBdEIsRUFBdUM7QUFFNUM7QUFDQUEsRUFBQUEsTUFBTSxDQUFDQyxJQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLFFBQU9DLGlCQUFVLGlCQUQxQjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDTkMsTUFBQUEsSUFBSSxFQUFFQyxxQkFBT0MsR0FBUDtBQURBO0FBRlosR0FERixFQU9FLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNsQyxRQUFJQyxNQUFNLEdBQUcsRUFBYjs7QUFDQSxRQUFHO0FBQ0QsWUFBTUMsT0FBTyxHQUFHSCxPQUFPLENBQUNKLElBQXhCO0FBQ0FNLE1BQUFBLE1BQU0sR0FBRyxNQUFNSCxPQUFPLENBQUNLLElBQVIsQ0FBYUMsYUFBYixDQUEyQkMsTUFBM0IsQ0FBa0NDLGFBQWxDLENBQWdEQyxNQUFoRCxDQUF1RDtBQUNsRUMsUUFBQUEsS0FBSyxFQUFFTixPQUFPLENBQUNNLEtBRG1EO0FBRWxFQyxRQUFBQSxDQUFDLEVBQUNQLE9BQU8sQ0FBQ1EsS0FGd0Q7QUFHbEVDLFFBQUFBLE9BQU8sRUFBQ1QsT0FBTyxDQUFDUyxPQUhrRDtBQUlsRUMsUUFBQUEsZ0JBQWdCLEVBQUNWLE9BQU8sQ0FBQ1UsZ0JBSnlDO0FBS2xFQyxRQUFBQSxJQUFJLEVBQUNYLE9BQU8sQ0FBQ1csSUFMcUQ7QUFNbEVDLFFBQUFBLElBQUksRUFBQ1osT0FBTyxDQUFDWSxJQU5xRDtBQU9sRW5CLFFBQUFBLElBQUksRUFBQ08sT0FBTyxDQUFDUCxJQVBxRDtBQVFsRW9CLFFBQUFBLElBQUksRUFBQ2IsT0FBTyxDQUFDYTtBQVJxRCxPQUF2RCxDQUFmO0FBVUgsS0FaQyxDQWNGLE9BQU1DLEdBQU4sRUFBVTtBQUFBOztBQUNSLGFBQU9oQixRQUFRLENBQUNpQixXQUFULENBQXFCO0FBQ3hCQyxRQUFBQSxVQUFVLEVBQUUsY0FBQUYsR0FBRyxDQUFDRyxJQUFKLDBFQUFVeEIsSUFBViwwRkFBZ0J5QixLQUFoQiw4RUFBdUJDLE1BQXZCLEtBQWlDLEdBRHJCO0FBRXZCMUIsUUFBQUEsSUFBSSxFQUFFO0FBQ0w7QUFDQzJCLFVBQUFBLE9BQU8sRUFBRSxlQUFBTixHQUFHLENBQUNHLElBQUosNkVBQVV4QixJQUFWLDZGQUFnQnlCLEtBQWhCLGdGQUF1QkcsTUFBdkIsS0FBaUM7QUFGdEM7QUFGaUIsT0FBckIsQ0FBUDtBQU9EOztBQUNELFdBQU92QixRQUFRLENBQUN3QixFQUFULENBQVk7QUFDakI3QixNQUFBQSxJQUFJLEVBQUVNO0FBRFcsS0FBWixDQUFQO0FBR0QsR0FuQ0gsRUFINEMsQ0F5QzVDOztBQUNBWCxFQUFBQSxNQUFNLENBQUNDLElBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsUUFBT0MsaUJBQVUsZ0JBRDFCO0FBRUVDLElBQUFBLFFBQVEsRUFBRTtBQUNOQyxNQUFBQSxJQUFJLEVBQUVDLHFCQUFPQyxHQUFQO0FBREE7QUFGWixHQURGLEVBT0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ2xDLFFBQUlDLE1BQU0sR0FBRyxFQUFiOztBQUNBLFFBQUc7QUFDRCxZQUFNQyxPQUFPLEdBQUdILE9BQU8sQ0FBQ0osSUFBeEI7QUFDQU0sTUFBQUEsTUFBTSxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ssSUFBUixDQUFhQyxhQUFiLENBQTJCQyxNQUEzQixDQUFrQ0MsYUFBbEMsQ0FBZ0RFLEtBQWhELENBQXNEO0FBQ25FaUIsUUFBQUEsRUFBRSxFQUFFdkIsT0FBTyxDQUFDdUIsRUFEdUQ7QUFFbkVqQixRQUFBQSxLQUFLLEVBQUVOLE9BQU8sQ0FBQ00sS0FGb0Q7QUFHbkViLFFBQUFBLElBQUksRUFBQ08sT0FBTyxDQUFDUDtBQUhzRCxPQUF0RCxDQUFmO0FBS0gsS0FQQyxDQVFGLE9BQU1xQixHQUFOLEVBQVU7QUFBQTs7QUFDUixhQUFPaEIsUUFBUSxDQUFDaUIsV0FBVCxDQUFxQjtBQUN4QkMsUUFBQUEsVUFBVSxFQUFFLGVBQUFGLEdBQUcsQ0FBQ0csSUFBSiw2RUFBVXhCLElBQVYsNkZBQWdCeUIsS0FBaEIsZ0ZBQXVCQyxNQUF2QixLQUFpQyxHQURyQjtBQUV2QjFCLFFBQUFBLElBQUksRUFBRTtBQUNMMkIsVUFBQUEsT0FBTyxFQUFFLGVBQUFOLEdBQUcsQ0FBQ0csSUFBSiw2RUFBVXhCLElBQVYsNkZBQWdCeUIsS0FBaEIsZ0ZBQXVCRyxNQUF2QixLQUFpQztBQURyQztBQUZpQixPQUFyQixDQUFQO0FBTUQ7O0FBQ0QsV0FBT3ZCLFFBQVEsQ0FBQ3dCLEVBQVQsQ0FBWTtBQUNqQjdCLE1BQUFBLElBQUksRUFBRU07QUFEVyxLQUFaLENBQVA7QUFHRCxHQTVCSCxFQTFDNEMsQ0F3RTVDOztBQUNBWCxFQUFBQSxNQUFNLENBQUNDLElBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsUUFBT0MsaUJBQVUsMEJBRDFCO0FBRUVDLElBQUFBLFFBQVEsRUFBRTtBQUNOQyxNQUFBQSxJQUFJLEVBQUVDLHFCQUFPQyxHQUFQO0FBREE7QUFGWixHQURGLEVBT0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ2xDLFFBQUlDLE1BQU0sR0FBRyxFQUFiO0FBQ0EsVUFBTUMsT0FBTyxHQUFHSCxPQUFPLENBQUNKLElBQXhCOztBQUNFLFFBQUc7QUFDRE0sTUFBQUEsTUFBTSxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ssSUFBUixDQUFhQyxhQUFiLENBQTJCQyxNQUEzQixDQUFrQ0MsYUFBbEMsQ0FBZ0RvQixhQUFoRCxDQUE4RDtBQUMzRWxCLFFBQUFBLEtBQUssRUFBRU4sT0FBTyxDQUFDTSxLQUQ0RDtBQUUzRUMsUUFBQUEsQ0FBQyxFQUFDUCxPQUFPLENBQUNRLEtBRmlFO0FBRzNFZixRQUFBQSxJQUFJLEVBQUNPLE9BQU8sQ0FBQ1A7QUFIOEQsT0FBOUQsQ0FBZjtBQUtELEtBTkQsQ0FRRixPQUFNcUIsR0FBTixFQUFVO0FBQUE7O0FBQ1IsYUFBT2hCLFFBQVEsQ0FBQ2lCLFdBQVQsQ0FBcUI7QUFDeEJDLFFBQUFBLFVBQVUsRUFBRSxlQUFBRixHQUFHLENBQUNHLElBQUosNkVBQVV4QixJQUFWLDZGQUFnQnlCLEtBQWhCLGdGQUF1QkMsTUFBdkIsS0FBaUMsR0FEckI7QUFFdkIxQixRQUFBQSxJQUFJLEVBQUU7QUFDTDJCLFVBQUFBLE9BQU8sRUFBRSxlQUFBTixHQUFHLENBQUNHLElBQUosNkVBQVV4QixJQUFWLDZGQUFnQnlCLEtBQWhCLGdGQUF1QkcsTUFBdkIsS0FBaUM7QUFEckM7QUFGaUIsT0FBckIsQ0FBUDtBQU1EOztBQUNELFdBQU92QixRQUFRLENBQUN3QixFQUFULENBQVk7QUFDakI3QixNQUFBQSxJQUFJLEVBQUVNO0FBRFcsS0FBWixDQUFQO0FBR0gsR0E3Qkg7QUFnQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJUm91dGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7UExVR0lOX0lEfSBmcm9tIFwiLi4vLi4vY29tbW9uXCI7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAa2JuL2NvbmZpZy1zY2hlbWEnO1xuXG5leHBvcnQgZnVuY3Rpb24gZGVmaW5lUm91dGVzKHJvdXRlcjogSVJvdXRlcikge1xuXG4gIC8vIGZvciBzZWFyY2ggZG9jdW1lbnRzIDpcbiAgcm91dGVyLnBvc3QoICAgICAgXG4gICAge1xuICAgICAgcGF0aDogYC9hcGkvJHtQTFVHSU5fSUR9L2VsYXN0aWMvc2VhcmNoYCxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgICAgYm9keTogc2NoZW1hLmFueSgpXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGxldCByZXN1bHQgPSB7fTtcbiAgICAgICAgdHJ5e1xuICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSByZXF1ZXN0LmJvZHk7XG4gICAgICAgICAgcmVzdWx0ID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuc2VhcmNoKHtcbiAgICAgICAgICAgICAgaW5kZXg6IHBheWxvYWQuaW5kZXgsXG4gICAgICAgICAgICAgIHE6cGF5bG9hZC5xdWVyeSxcbiAgICAgICAgICAgICAgX3NvdXJjZTpwYXlsb2FkLl9zb3VyY2UsXG4gICAgICAgICAgICAgIF9zb3VyY2VfZXhjbHVkZXM6cGF5bG9hZC5fc291cmNlX2V4Y2x1ZGVzLFxuICAgICAgICAgICAgICBmcm9tOnBheWxvYWQuZnJvbSxcbiAgICAgICAgICAgICAgc2l6ZTpwYXlsb2FkLnNpemUsXG4gICAgICAgICAgICAgIGJvZHk6cGF5bG9hZC5ib2R5LFxuICAgICAgICAgICAgICBzb3J0OnBheWxvYWQuc29ydCxcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgY2F0Y2goZXJyKXtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5tZXRhPy5ib2R5Py5lcnJvcj8uc3RhdHVzIHx8IDQxN1xuICAgICAgICAgICAgLGJvZHk6IHtcbiAgICAgICAgICAgICAgLy9tZXNzYWdlOiBKU09OLnN0cmluZ2lmeShlcnIubWV0YT8uYm9keT8uZXJyb3IpIHx8IFwicmVhc29uIG5vdCBzcGVjaWZpZWRcIlxuICAgICAgICAgICAgICAgbWVzc2FnZTogZXJyLm1ldGE/LmJvZHk/LmVycm9yPy5yZWFzb24gfHwgXCJyZWFzb24gbm90IHNwZWNpZmllZFwiXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiByZXN1bHQsXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG5cbiAgLy8gZm9yIHNhdmluZyBkYXRhOlxuICByb3V0ZXIucG9zdCggICAgICBcbiAgICB7XG4gICAgICBwYXRoOiBgL2FwaS8ke1BMVUdJTl9JRH0vZWxhc3RpYy9pbmRleGAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKVxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgICBsZXQgcmVzdWx0ID0ge307XG4gICAgICAgIHRyeXtcbiAgICAgICAgICBjb25zdCBwYXlsb2FkID0gcmVxdWVzdC5ib2R5O1xuICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGV4KHtcbiAgICAgICAgICAgIGlkOiBwYXlsb2FkLmlkLFxuICAgICAgICAgICAgaW5kZXg6IHBheWxvYWQuaW5kZXgsXG4gICAgICAgICAgICBib2R5OnBheWxvYWQuYm9keVxuICAgICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgY2F0Y2goZXJyKXtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IGVyci5tZXRhPy5ib2R5Py5lcnJvcj8uc3RhdHVzIHx8IDQxN1xuICAgICAgICAgICAgLGJvZHk6IHtcbiAgICAgICAgICAgICAgbWVzc2FnZTogZXJyLm1ldGE/LmJvZHk/LmVycm9yPy5yZWFzb24gfHwgXCJyZWFzb24gbm90IHNwZWNpZmllZFwiXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiByZXN1bHQsXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG4gIC8vIGZvciBkZWxldGUgZGF0YSBieSBxdWVyeSA6XG4gIHJvdXRlci5wb3N0KCAgICAgIFxuICAgIHtcbiAgICAgIHBhdGg6IGAvYXBpLyR7UExVR0lOX0lEfS9lbGFzdGljL2RlbGV0ZV9ieV9xdWVyeWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKVxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgICBsZXQgcmVzdWx0ID0ge307XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSByZXF1ZXN0LmJvZHk7ICAgICAgICAgXG4gICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuZGVsZXRlQnlRdWVyeSh7XG4gICAgICAgICAgICAgIGluZGV4OiBwYXlsb2FkLmluZGV4LFxuICAgICAgICAgICAgICBxOnBheWxvYWQucXVlcnksXG4gICAgICAgICAgICAgIGJvZHk6cGF5bG9hZC5ib2R5XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXG4gICAgICAgIGNhdGNoKGVycil7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICAgICAgc3RhdHVzQ29kZTogZXJyLm1ldGE/LmJvZHk/LmVycm9yPy5zdGF0dXMgfHwgNDE3XG4gICAgICAgICAgICAgICxib2R5OiB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZTogZXJyLm1ldGE/LmJvZHk/LmVycm9yPy5yZWFzb24gfHwgXCJyZWFzb24gbm90IHNwZWNpZmllZFwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogcmVzdWx0LFxuICAgICAgICB9KTtcbiAgICB9ICBcbiAgKTtcblxufVxuIl19